<?php
session_start();
$user_otp = $_POST['varify_otp_sms'];
				$verify_otp = $_SESSION['otpsms'];

			
			
			    
			   if($verify_otp == $user_otp) {
			       $date = date_default_timezone_set('Asia/Kolkata');
			       $today = date("g:i a"); 
$_SESSION['timestamp'] = $today; //set new timestamp
          $_SESSION['otpsmssuccessfull_verification']  = $user_otp;
            $ressms = 'Successfully Varify SMS OTP';   
 
            echo json_encode($ressms);

        }
        
        else{
          
           $resssms ='SMS OTP Not Matched';
 
            echo json_encode($resssms);  
        }
        
        
		
				
       
				
?>