<?php

function connection() {
    $link = mysqli_connect("localhost", "dmsfplsm_dmsf2", "dmsf2@123", "dmsfplsm_dmsf2");
    return $link;
}

?>
