<?php
session_start();
$user_otp = $_POST['varify_otp_email'];
				$verify_otp = $_SESSION['otp'];

			
			
			    
			   if($verify_otp == $user_otp) {

$_SESSION['timestamp'] = time(); //set new timestamp
            $_SESSION['otpemailsuccessfull_verification']  = $user_otp;
            $res = 'Successfully Varify OTP';   
 
            echo json_encode($res);

        }
        
        else{
          
           $ress ='Otp Not Matched';
 
            echo json_encode($ress);  
        }
        
        
		
				
       
				
?>